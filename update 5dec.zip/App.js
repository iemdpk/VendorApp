import React,{useState,useEffect} from 'react';
import { View, Text,AsyncStorage,Dimensions,TouchableOpacity } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { Button, ThemeProvider,Header,Input } from 'react-native-elements';
import Icon from 'react-native-vector-icons/FontAwesome';
import Carousel from 'simple-carousel-react-native';
import PhoneInput from "react-native-phone-number-input";
import OTPTextInput from "react-native-otp-textinput";

function HomeScreen({navigation}) {

    const [fullName, setFullname] = useState();
    const [fullAdd, setFulladd] = useState();
    const [howchild, setHowchild] = useState();
    const [phone, setPhone] = useState();

    const [load, setLoad] = useState(false);

    const [otp,setOtp] = useState();

    return (


        <View style={{ flex: 1 }}>

        <Carousel showBubbles={false}   height='70%' width={Dimensions.get('window').width}>

        <View style={{flex:1,backgroundColor:'#0984e3',alignItems:'center',justifyContent:'center'}}>

        <Text style={{fontSize:35}}>Lagge Image</Text>

        </View>

        <View style={{flex:1,backgroundColor:'#ff7675',alignItems:'center',justifyContent:'center'}}>

        <Text style={{fontSize:35}}>Lagge Image 2</Text>

        </View>
        <View style={{flex:1,backgroundColor:'#ffeaa7',alignItems:'center',justifyContent:'center'}}>

        <Text style={{fontSize:35}}>Laggee Image 3</Text>

        </View>



        </Carousel>

        <View style={{height:'30%',width:Dimensions.get('window').width,alignItems:'center',justifyContent:'center'}}>
        
         <PhoneInput
            
            defaultCode="DM"
            onChangeText={(text) => {
       //  alert(text);
            }}
            onChangeFormattedText={(text) => {
                setOtp(text);
            }}
            withDarkTheme
            withShadow
            autoFocus
          />
        <Text></Text>
        <Button buttonStyle={{height:50,width:100}}  title="Register" onPress={()=>{ 
        
                            navigation.navigate('Home');

        
        }} />
     
        </View>

        </View>


    );
}

function ups({navigation}){

    useEffect(() => {

        AsyncStorage.getItem('Full_Name').then((value)=>{

            if(value == null){
                navigation.navigate('Regi');
            }
            else{
                navigation.navigate('Home');
            }


        });



    },[]);

    return(null);

}


function OtpVeri({navigation}){

    const [name,setName] = useState();

    function checko(){

        if(name == '1234'){
            navigation.navigate('stock');
        }
        else{
            alert("It is not Correct");
        }

    }

    return(

        <View style={{ flex: 1,backgroundColor:'#222f3e'}}>
            <Header
                backgroundColor="#48dbfb"
                centerComponent={{
                    text: "Enter OTP",
                    style: { color: "white",fontWeight:'bold', fontSize: 23 },

                }}
            />

            <View style={{flex: 0.7,
        alignItems: "center",
        justifyContent: "center",
        backgroundColor: "#48dbfb",
        borderBottomRightRadius: 60,
        borderBottomLeftRadius: 60,}}>
                <Icon name="phone" size={150} color="white" />
            </View>


            <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
                <OTPTextInput
                    handleTextChange={(val) => {
                        setName(val);
                    }}
                    textInputStyle={{color:'white'}}
                />
                <Text></Text>
                <TouchableOpacity style={{ marginTop: 15 }} onPress={checko}>
                    <Icon name="play" size={60} color="white" />
                </TouchableOpacity>
            </View>
        </View>

    );

}


function StockPage(){
    return(
        <View style={{flex:1,justifyContent:'center',alignItems:'center'}}>

        <Text style={{fontSize:25,fontWeight:'bold'}}>Product Page</Text>

        </View>
    )
}



const Stack = createStackNavigator();

function App() {
    return (
        <NavigationContainer>
        <Stack.Navigator initialRouteName="Regi">
        <Stack.Screen name="ups" options={{headerShown:false}}  component={ups} />
        <Stack.Screen name="Regi" options={{headerShown:false}}  component={HomeScreen} />
        <Stack.Screen name="Home" options={{headerShown:false}}  component={OtpVeri} />
        <Stack.Screen name="stock" options={{headerShown:false}}  component={StockPage} />

        </Stack.Navigator>
        </NavigationContainer>
    );
}

export default App;

