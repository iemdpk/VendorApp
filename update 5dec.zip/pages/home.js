import React from 'react';
import {View,Text} from 'react-native';



function home(){
    
    return(
    
        <View style={{flex:1,justifyContent:'center',alignItems:'center'}}>
            
            <Text>It is on Home</Text>
            <Text>Lets do that work</Text>

        </View>

    );

}

export default home;
