import * as firebase from 'firebase';

var firebaseConfig = {
     apiKey: "AIzaSyA22AiLHfINGnK0t3VVp50ThbI9Jcnx1mY",
    authDomain: "safer-f2eda.firebaseapp.com",
    databaseURL: "https://safer-f2eda.firebaseio.com",
    projectId: "safer-f2eda",
    storageBucket: "safer-f2eda.appspot.com",
    messagingSenderId: "796425153203",
    appId: "1:796425153203:web:787b831bbd95080e4e5ec6",
    measurementId: "G-FPFZZC63WM"
  };

const Firebase =  firebase.initializeApp(firebaseConfig);


export default Firebase;
